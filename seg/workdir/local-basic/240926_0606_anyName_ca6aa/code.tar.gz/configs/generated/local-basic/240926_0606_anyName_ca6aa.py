_base_ = '../../config_mic_v4_META_EMAN.py'
name = '240926_0606_anyName_ca6aa'
work_dir = 'work_dirs/local-basic/240926_0606_anyName_ca6aa'
git_rev = '1df685c4c10189789b6be8e67b4bd0ff51d27cfc'
